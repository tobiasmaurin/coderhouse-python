from setuptools import setup

setup(
    	name ='TuModeloDeClientes+Maurin',
    	version ='1.0',
    	author = "Maurin Tobias",
    	description = "Se esta haciendo la version 1.0 de la preentrega",
    	author_email = "tobimaurin@hotmail.com",
    	packages = ["modulos"]
	)