#2DO ENTREGABLE

class clientes:

    def _init_(self, nombre, edad, mail, interes):
        self.nombre = nombre
        self.edad = edad
        self.mail = mail
        self.interes = interes


    def _str_(self):
        return 'El cliente '+ self.nombre +' fue registrado en la base de datos'
    

    def comprar(self, producto, sucursal):
        self.producto = producto
        self.sucursal = sucursal
        print('El cliente '+ self.nombre +' compro un/a '+ self.producto + ' en la sucursal '+ self.sucursal)